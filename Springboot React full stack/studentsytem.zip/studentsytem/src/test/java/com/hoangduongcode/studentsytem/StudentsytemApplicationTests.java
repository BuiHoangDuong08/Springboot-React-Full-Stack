package com.hoangduongcode.studentsytem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsytemApplicationTests {

	@Test
	void contextLoads() {
	}

}
